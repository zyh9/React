//配置webpack与electron服务
const os = require('os');  //获取系统信息

module.exports = { //es5导出对象
    port: 1111,
    getDeviceIP: function(){  //获取设备ip
        let localhost = null;
        const network = os.networkInterfaces();
        const arr = Object.keys(network);
        
        for(let i=0; i<arr.length; i++){
			if(/以太网/g.test(arr[i]) || /WLAN/g.test(arr[i])){
				const ipAttr = network[arr[i]];
				const len = ipAttr.length;
				for(var j=0; j<len; j++){
					if(/192\.168\./.test(ipAttr[j].address)){
						localhost = ipAttr[j].address;
					}
					if(localhost){

						return localhost;
					}
				}
			}
		}
		return localhost = 'localhost';
    }
}

